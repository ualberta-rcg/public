#!/bin/bash
#SBATCH --ntasks=4                    # Number of tasks (also 4 core/cpus as be defualt is 1 cpu per task)
#SBATCH --mem-per-cpu=250            # Asking for 0.25 GB per core or in this case 1GB total as this job has 4 cores 
#SBATCH --time=0-00:06                # Runtime in D-HH:MM
#SBATCH -o q19-%j.out           # File to which STDOUT will be written
#SBATCH -e q19-%j.err           # File to which STDERR will be written
#SBATCH --mail-type=ALL               # Type of email notification- BEGIN,END,FAIL,ALL
#SBATCH --mail-user=no.email@ubc.ca   # Email to which notifications will be sent
##                   ^
##                   |
##                   --- Replace the above email address with to your own
sleep 300
hostname
