#!/bin/bash
#SBATCH --ntasks=4                    # Number of cores/tasks
#SBATCH -t 0-00:02                    # Runtime in D-HH:MM
#SBATCH -o slurm-mem-%j.out           # File to which STDOUT will be written
#SBATCH -e slurm-mem-%j.err           # File to which STDERR will be written
#SBATCH --mail-type=ALL               # Type of email notification- BEGIN,END,FAIL,ALL
#SBATCH --mail-user=no.email@ubc.ca   # Email to which notifications will be sent
##                   ^
##                   |
##                   --- Replace the above email address with to your own
sleep 200
hostname
