#!/bin/bash
#SBATCH --ntasks=1                    # Number of cores/tasks
#SBATCH --nodes=1                     # Number of nodes, ensure that all cores are on one machine
#SBATCH --time=0-00:02                # Runtime in D-HH:MM
#SBATCH --mail-type=ALL               # Type of email notification- BEGIN,END,FAIL,ALL
#SBATCH --mail-user=no.email@ubc.ca   # Email to which notifications will be sent
##                   ^
##                   |
##                   --- Replace the above email address with to your own
sleep 30
hostname
