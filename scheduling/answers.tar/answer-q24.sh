#!/bin/bash
#SBATCH --ntasks=4                    # Number of tasks (also 4 core/cpus as be defualt is 1 cpu per task)
#SBATCH --mem-per-cpu=1000            # Asking for 1 GB per core or in this case 4GB total as this job has 4 cores 
#SBATCH --time=0-00:02                # Runtime in D-HH:MM
#SBATCH --job-name=mem-par1           # Jobname
#SBATCH -o %x-%j.out                  # set the outputfile to be the jobs name followed by .out
#SBATCH --mail-type=ALL               # Type of email notification- BEGIN,END,FAIL,ALL
#SBATCH --mail-user=no.email@ubc.ca   # Email to which notifications will be sent
##                   ^
##                   |
##                   --- Replace the above email address with to your own
sleep 100
hostname
