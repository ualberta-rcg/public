#!/bin/bash
#SBATCH --ntasks=1                    # Number of cores/tasks
#SBATCH --nodes=1                     # Number of nodes, ensure that all cores are on one machine
#SBATCH --time=0-00:02                # Runtime in D-HH:MM
#SBATCH --job-name=array-job4      # Sets the Jobs name
#SBATCH --array=1,4                   # array with 2 tasks with indexes:1,4
#SBATCH -o %x-%a.out                 # File to which STDOUT will be written
#SBATCH --mail-type=ALL               # Type of email notification- BEGIN,END,FAIL,ALL
#SBATCH --mail-user=no.email@ubc.ca   # Email to which notifications will be sent
##                   ^
##                   |
##                   --- Replace the above email address with to your own

echo "This jobs name is:    $SLURM_JOB_NAME"
echo "This jobs jobid is:    $SLURM_JOB_ID"
echo "This jobs is running on host:  `hostname`"
echo "This jobs runs on list of nodes their names are: $SLURM_JOB_NODELIST"
echo "The number of nodes that this job runs on is: $SLURM_JOB_NUM_NODES"
echo "The number of tasks in this job is: $SLURM_NTASKS"
echo "The number of tasks per node in this job is: $SLURM_TASKS_PER_NODE" 
echo "This jobs taskid is:  $SLURM_ARRAY_TASK_ID"   
echo 
echo
echo "Printing all the slurm variables:"
printenv | grep SLURM
echo
sleep 110
