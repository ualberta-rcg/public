#!/bin/bash
#SBATCH --ntasks=4                    # Number of cores/tasks
#SBATCH --mem 1000                    # asking fo 4GB of RAM in the job 
#SBATCH -t 0-00:20                    # Runtime in D-HH:MM
#SBATCH -o q20-%j.out                 # File to which STDOUT will be written
#SBATCH -e q20-%j.err                 # File to which STDERR will be written
#SBATCH --mail-type=ALL               # Type of email notification- BEGIN,END,FAIL,ALL
#SBATCH --mail-user=no.email@ubc.ca   # Email to which notifications will be sent
##                   ^
##                   |
##                   --- Replace the above email address with to your own
./cryptic
hostname
